//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by DHtmlEditDemo.rc
//
#define IDD_MAIN_DIALOG                 102
#define ID_TIMER_COMBO_FONTSIZE         107
#define IDR_MAINFRAME                   128
#define IDD_TABLE_PROP                  130
#define IDD_HR_PROP                     131
#define IDC_BUTTON_TABLE                1001
#define IDC_BUTTON_ROW_ABOVE            1002
#define IDC_EDIT_BorderWidth            1002
#define IDC_EDIT_BORDERCOLOR            1003
#define IDC_BUTTON_ROW_BELOW            1004
#define IDC_EDIT_CELLPADDING            1004
#define IDC_BUTTON_BGCOLOR              1005
#define IDC_EDIT_CELLSPACING            1005
#define IDC_BUTTON_CLEAR                1006
#define IDC_EDIT_BACKGCOLOR             1006
#define IDC_BUTTON_BGCOLOR_CELL         1007
#define IDC_EDIT_HEIGHT                 1007
#define IDC_BUTTON_TABLEPROP            1008
#define IDC_CHECK_DESIGN                1009
#define IDC_BUTTON_DELETE_ROW           1010
#define IDC_COMBO_SHADE                 1010
#define IDC_BUTTON_NAVIGATE             1011
#define IDC_BUTTON_DELETE_COL           1012
#define IDC_EDIT_WIDTH                  1012
#define IDC_BUTTON_HR                   1013
#define IDC_EDIT_SIZE                   1013
#define IDC_EDIT_COLOR                  1014
#define IDC_BUTTON_HRPROP               1014
#define IDC_BUTTON_COL_LEFT             1015
#define IDC_BUTTON_FORECOLOR            1016
#define IDC_BUTTON_BACKCOLOR            1017
#define IDC_COMBO_FONTNAME              1018
#define IDC_BUTTON_REMOVEFORMAT         1019
#define IDC_CHECK_BOLD                  1020
#define IDC_CHECK_ITALIC                1021
#define IDC_CHECK_UNDERLINE             1022
#define IDC_CHECK_LEFTALIGN             1023
#define IDC_CHECK_CENTERALIGN           1024
#define IDC_CHECK_UNORDERLIST           1025
#define IDC_CHECK_RIGHTALIGN            1026
#define IDC_CHECK_ORDERLIST             1027
#define IDC_BUTTON_IMAGE                1028
#define IDC_BUTTON_LINK                 1029
#define IDC_COMBO_FONTSIZE              1030
#define IDC_BUTTON_COL_RIGHT            1031
#define IDC_BUTTON_COMBINE              1032
#define IDC_BUTTON_SPLIT                1033
#define IDC_BUTTON_SAVE                 1034
#define IDC_BUTTON_HELP                 1035
#define IDC_BUTTON_NOBR                 1036
#define IDC_CHECK_SOURCE                1037
#define IDC_BUTTON_LOAD                 1038
#define IDC_BUTTON_GOBACK               1039
#define IDC_STATIC_EDITOR               1040
#define IDC_BUTTON_GOFORWARD            1041
#define IDC_EDIT_URL                    1042
#define IDC_STATIC_URL                  1043
#define IDC_BUTTON_HTML5                1044
#define IDC_COMBO_RULE                  1389

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        136
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1048
#define _APS_NEXT_SYMED_VALUE           108
#endif
#endif
